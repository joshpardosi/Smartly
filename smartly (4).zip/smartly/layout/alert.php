<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script><script><?php
    if (isset($_SESSION['status']) && isset($_SESSION['message'])):
    ?>
      // Ambil data status dan pesan dari session
      let status = "<?php echo $_SESSION['status']; ?>";
      let message = "<?php echo $_SESSION['message']; ?>";
      // Tampilkan notifikasi sesuai status
      Swal.fire({
        icon: status,
        title: status === "success" ? 'Success!' : 'Failed!',
        text: message,
        timer: 2000,
        confirmButtonColor: status === "success" ? '#28a745' : '#d33'
      });
      <?php
      unset($_SESSION['status']);
      unset($_SESSION['message']);
      ?>
    <?php endif; ?></script>