<?php
$hostname = "localhost";
$username = "";
$password = "";
$database = "";

$db = mysqli_connect($hostname, $username, $password, $database);
$db->query("SET time_zone = '+07:00'");
?>